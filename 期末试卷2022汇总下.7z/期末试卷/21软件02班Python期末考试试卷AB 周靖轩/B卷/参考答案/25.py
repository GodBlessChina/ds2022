import numpy
import pandas as pd

df1 = pd.read_excel('students.xlsx',sheet_name='s1')
df2 = pd.read_excel('students.xlsx',sheet_name='s2')

df = pd.merge(df1,df2,how='left').iloc[:,:5]

# df.to_csv('data.csv',index=False,encoding='utf-8')

df = df.loc[df['grade'] >= numpy.int64(90)]


df = df.sort_values(by='grade',ascending=False)


print(df)
# df.to_csv(r'C:\Users\godblesschina2befree\Desktop\data.csv',index=False,encoding='utf-8')

