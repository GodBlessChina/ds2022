import pandas as pd

df1 = pd.read_excel('students.xlsx',sheet_name='s1')
df2 = pd.read_excel('students.xlsx',sheet_name='s2')

df1.to_csv('s1.csv')
df2.to_csv('s2.csv')
