s="88kop543tukj64"
i = ''
for c in s:
    if c<='9' and c>='0':
        i+=c
i=int(i)
print(i, type(i))
