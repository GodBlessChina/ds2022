import numpy as np

A = np.array([[15,9,7],[6,19,0],[5,14,2]])
B = np.array([[1,2,4],[6,7,11],[5,9,6]])

C = A.dot(B)
print(C)
