import requests
url = "https://godblesschina.github.io/codeshare/students.xlsx"
# content = requests.get(url,proxies={"https":'127.0.0.1:10809'}).content
content = requests.get(url).content
f = open("students.xlsx","wb")
f.write(content)
f.close()
