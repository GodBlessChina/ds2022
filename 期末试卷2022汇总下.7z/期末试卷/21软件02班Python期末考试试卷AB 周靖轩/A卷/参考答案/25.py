import pandas as pd

df1 = pd.read_excel('students.xlsx',sheet_name='s1')
df2 = pd.read_excel('students.xlsx',sheet_name='s2')

pd.set_option('display.unicode.ambiguous_as_wide', True)
pd.set_option('display.unicode.east_asian_width', True)
pd.set_option('display.width', 180)

df = pd.merge(df1,df2,how='left').iloc[:,:5] # 逗号左边是行右边是列
# .iloc[0:4]获取0-3行
row12 = df[0:2]
print(df)
print("---------------------------------------------------------")
print(row12)
