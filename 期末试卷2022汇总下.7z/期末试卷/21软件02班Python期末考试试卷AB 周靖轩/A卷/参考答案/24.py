import pandas as pd

df1 = pd.read_excel('students.xlsx',sheet_name='s1')
df2 = pd.read_excel('students.xlsx',sheet_name='s2')

print(df1)
print(df2)
