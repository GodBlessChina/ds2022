A=[[15,9,7],[6,19,0],[5,14,2]]

maxvalue = A[0][0]
minvalue = A[0][0]

for row in range(A.__len__()):
    for column in range((A[row].__len__())):
        if maxvalue < A[row][column]:
            maxvalue = A[row][column]
        if minvalue > A[row][column]:
            minvalue = A[row][column]
print(maxvalue)
print(minvalue)
