s="abcABCDkW3L1l23Kdeflkm8073@4#$78"
s1 = ''
s2 = ''
for i in s:
    if i>='a' and i<='z':
        s1 += i
s2 = s1.upper()
print(s1)
print(s2)
